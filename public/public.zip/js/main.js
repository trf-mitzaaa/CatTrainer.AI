// js/main.js
import { auth }           from './firebase-config.js';
import { listenAuth, googleSignIn, emailRegister, emailLogin, sendOtp, verifyOtp, logout }
  from './auth.js';
import { loadUserData, completeLevel, buyItem, grantAchievement }
  from './db.js';
import { SUBJECTS, SHOP_ITEMS, ACHIEVEMENTS, getHeroClass, getHeroBadge, getReward, randomDialogue }
  from './game.js';
import { generateLesson, BattleManager }
  from './battle.js';
import { showToast, showPage, showScreen, updateHUD, spawnPawPrints,
  spawnParticles, typewriterEffect, updateBattleHP, shakeElement,
  showVictory, hideVictory, showDefeat, hideDefeat, confettiBurst }
  from './ui.js';
import { renderSettings, checkAndGrantVerifiedBonus }
  from './settings.js';

// ── App State ─────────────────────────────────
let currentUser     = null;
let userData        = null;
let currentSubject  = null;
let battleManager   = null;
let activeLevelNode = null;
let currentLevelIndex = 0;

// ── Boot ──────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  spawnPawPrints();
  spawnParticles();
  bindAuthButtons();
  bindNavigation();
  bindBattleButtons();
  bindShopButtons();
  bindOverlayButtons();

  // When settings.js resets progress, reload and re-render
  window.addEventListener('userDataReset', async () => {
    userData = await loadUserData(currentUser.uid);
    updateHUD(userData);
    renderAccountPage();
  });

  listenAuth(
      async (user) => {
        currentUser = user;
        userData    = await loadUserData(user.uid);

        // Grant email-verified bonus if applicable
        const bonusGranted = await checkAndGrantVerifiedBonus(currentUser.uid, userData);
        if (bonusGranted) {
          userData = await loadUserData(currentUser.uid);
        }

        showScreen('appScreen');
        updateHUD(userData);
        renderWorldMap();
        showPageCustom('worldmapPage');
      },
      () => {
        currentUser = null;
        userData    = null;
        showScreen('authScreen');
      }
  );
});

// ══ AUTH BINDINGS ════════════════════════════
function bindAuthButtons() {
  // Tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const tab = btn.dataset.tab;
      document.getElementById('loginTab').style.display    = tab === 'login'    ? '' : 'none';
      document.getElementById('registerTab').style.display = tab === 'register' ? '' : 'none';
    });
  });

  // Google
  document.getElementById('googleLoginBtn')?.addEventListener('click', googleSignIn);

  // Email login
  document.getElementById('emailLoginBtn')?.addEventListener('click', async () => {
    const email = document.getElementById('loginEmail').value.trim();
    const pwd   = document.getElementById('loginPassword').value;
    if (!email || !pwd) return showToast('❌ Nu ai completat câmpurile!');
    await emailLogin(email, pwd);
  });

  // Email register
  document.getElementById('emailRegisterBtn')?.addEventListener('click', async () => {
    const name  = document.getElementById('regName').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const pwd   = document.getElementById('regPassword').value;
    if (!name || !email || !pwd) return showToast('❌ Completează toate câmpurile!');
    await emailRegister(name, email, pwd);
  });

  // Phone OTP
  document.getElementById('phoneLoginBtn')?.addEventListener('click', async () => {
    const phone = document.getElementById('loginPhone')?.value.trim();
    if (!phone) return showToast('❌ Introduceți numărul de telefon!');
    await sendOtp(phone);
    const otpSection = document.getElementById('otpSection');
    if (otpSection) otpSection.style.display = '';
  });

  document.getElementById('verifyOtpBtn')?.addEventListener('click', async () => {
    const otp = document.getElementById('otpInput').value.trim();
    if (!otp) return showToast('❌ Introduceți codul secret!');
    await verifyOtp(otp);
  });

  // Logout
  document.getElementById('logoutBtn')?.addEventListener('click', async () => {
    await logout();
  });
}

// ══ NAVIGATION ═══════════════════════════════
function bindNavigation() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const page = btn.dataset.page;
      if (!page) return;
      document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      if (page === 'worldmap') {
        renderWorldMap();
        showPageCustom('worldmapPage');
      } else if (page === 'account') {
        renderAccountPage();
        showPageCustom('accountPage');
      } else if (page === 'shop') {
        renderShop();
        showPageCustom('shopPage');
      } else if (page === 'battle') {
        showPageCustom('battlePage');
      }
    });
  });

  // HUD account button
  document.getElementById('accountBtn')?.addEventListener('click', () => {
    renderAccountPage();
    showPageCustom('accountPage');
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('[data-page="account"]')?.classList.add('active');
  });

  // Back buttons
  document.getElementById('backToRealms')?.addEventListener('click', () => {
    renderWorldMap();
    showPageCustom('worldmapPage');
    document.querySelector('[data-page="worldmap"]')?.classList.add('active');
  });

  document.getElementById('backToLevelMap')?.addEventListener('click', () => {
    if (currentSubject) openLevelMap(currentSubject);
    else showPageCustom('worldmapPage');
  });
}

function showPageCustom(pageId) {
  document.querySelectorAll('.page').forEach(p => {
    p.style.display = p.id === pageId ? '' : 'none';
  });
}

// ══ WORLD MAP ════════════════════════════════
function renderWorldMap() {
  const container = document.getElementById('subjectRealms');
  if (!container) return;
  container.innerHTML = '';

  SUBJECTS.forEach(subject => {
    const progress  = userData?.realmProgress?.[subject.key] || {};
    const completed = (progress.completedLevels || []).length;
    const total     = subject.levels.length;
    const pct       = Math.round((completed / total) * 100);

    const card     = document.createElement('div');
    card.className = 'realm-card';
    card.innerHTML = `
      <span class="realm-icon">${subject.icon}</span>
      <div class="realm-name">${subject.name}</div>
      <div class="realm-levels">${completed}/${total} nivele completate</div>
      <div class="realm-progress-bar">
        <div class="realm-progress-fill" style="width:${pct}%"></div>
      </div>
      ${completed === total ? '<div class="realm-lock" title="Completat!">✅</div>' : ''}
    `;
    card.style.setProperty('--realm-color', subject.color);
    card.style.borderColor = pct > 0 ? subject.color : '';
    card.addEventListener('click', () => openLevelMap(subject));
    container.appendChild(card);
  });
}

// ══ LEVEL MAP ════════════════════════════════
function openLevelMap(subject) {
  currentSubject = subject;
  document.getElementById('levelMapTitle').textContent = `${subject.icon} Tărâmul ${subject.name}`;

  const progress  = userData?.realmProgress?.[subject.key] || {};
  const completed = progress.completedLevels || [];
  const current   = progress.currentLevel   || 0;

  const road = document.getElementById('levelRoad');
  road.innerHTML = '';

  subject.levels.forEach((level, i) => {
    const isDone   = completed.includes(i);
    const isLocked = i > current;
    const isBoss   = level.type === 'boss';

    // Boss warning banner
    if (isBoss && i > 0) {
      const warn = document.createElement('div');
      warn.style.cssText = 'text-align:center; font-family:var(--font-ui); color:var(--red); font-size:13px; margin:-20px 0 10px; opacity:0.85;';
      warn.textContent = '⚠️ Ai grijă! Următorul nivel este un Boss!';
      road.appendChild(warn);
    }

    const node     = document.createElement('div');
    node.className = 'level-node';
    node.innerHTML = `
      <button class="level-node-btn ${level.type}-node ${isDone ? 'completed' : ''} ${isLocked ? 'locked' : ''}"
              data-index="${i}"
              ${isLocked ? 'disabled' : ''}>
        ${isDone ? '✅' : level.icon}
        <small style="font-size:9px; font-family:var(--font-title); color:var(--beige); display:block; margin-top:2px">
          ${i + 1}
        </small>
      </button>
      <div class="level-node-label">
        <div class="level-node-title">${level.title}</div>
        <span class="level-type-badge badge-${level.type}">
          ${level.type === 'lesson' ? '📖 Lecție' : level.type === 'boss' ? '👑 Boss' : '⚔️ Inamic'}
        </span>
      </div>
    `;

    const btn = node.querySelector('.level-node-btn');
    if (!isLocked) {
      btn.addEventListener('click', () => openBattle(subject, level, i));
    }

    road.appendChild(node);
  });

  showPageCustom('levelmapPage');
}

// ══ BATTLE ═══════════════════════════════════
async function openBattle(subject, level, levelIndex) {
  currentSubject    = subject;
  activeLevelNode   = level;
  currentLevelIndex = levelIndex;

  // Enemy name & sprite
  document.getElementById('enemyName').textContent = level.enemy || 'Magicianul Whiskers';
  const enemySprite = document.getElementById('enemySprite');
  enemySprite.src = level.type === 'boss' ? 'assets/Boss.png' : 'assets/Profesor.png';

  // Player name
  document.getElementById('playerNameBattle').textContent = userData?.displayName || 'Erou';

  // Reset HP bars
  document.getElementById('enemyHpFill').style.width  = '100%';
  document.getElementById('playerHpFill').style.width = '100%';
  document.getElementById('enemyHpText').textContent  = '100/100';
  document.getElementById('playerHpText').textContent = '100/100';

  // Reset battle UI
  const startLessonBtn = document.getElementById('startLessonBtn');
  const startBattleBtn = document.getElementById('startBattleBtn');
  const continueBtn    = document.getElementById('continueBtn');

  startLessonBtn.style.display = '';
  startLessonBtn.disabled      = false;
  startLessonBtn.textContent   = '📖 Studiază Lecția';

  startBattleBtn.style.display = 'none';
  startBattleBtn.disabled      = false;
  startBattleBtn.textContent   = '⚔️ Începe Bătălia!';

  continueBtn.style.display = 'none';
  continueBtn.disabled      = false;
  continueBtn.textContent   = '➡️ Continuă';
  continueBtn.onclick       = null;

  document.getElementById('lessonContent').style.display = 'none';
  document.getElementById('questionArea').style.display  = 'none';

  // Opening dialogue
  const dialogue = level.type === 'lesson'
      ? randomDialogue('lesson')
      : level.type === 'boss'
          ? randomDialogue('boss_warn')
          : randomDialogue('battle');

  typewriterEffect(document.getElementById('dialogueText'), dialogue, 25);
  showPageCustom('battlePage');
}

function bindBattleButtons() {
  // ── Study lesson ──────────────────────────
  document.getElementById('startLessonBtn')?.addEventListener('click', async () => {
    if (!activeLevelNode) return;
    const btn = document.getElementById('startLessonBtn');
    btn.textContent = '⏳ Se generează lecția...';
    btn.disabled    = true;

    try {
      const text = await generateLesson(activeLevelNode.topic);
      document.getElementById('lessonText').innerHTML =
          text.replace(/\n/g, '<br>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      document.getElementById('lessonContent').style.display = '';

      typewriterEffect(
          document.getElementById('dialogueText'),
          'Studiază bine această cunoaștere, tânăr învățăcel! Apoi testează-ți puterea! 📖',
          25
      );

      btn.style.display = 'none';

      if (activeLevelNode.type === 'lesson') {
        const continueBtn       = document.getElementById('continueBtn');
        continueBtn.style.display = '';
        continueBtn.textContent   = '✅ Lecție Completată!';
        continueBtn.onclick       = async () => { await finishLevel(true); };
      } else {
        document.getElementById('startBattleBtn').style.display = '';
      }
    } catch {
      showToast('❌ Nu am reușit să invoc pergamentul cunoașterii. Verifică cheia ta Gemini!');
      btn.textContent = '📖 Studiază Lecția';
      btn.disabled    = false;
    }
  });

  // ── Start battle ──────────────────────────
  document.getElementById('startBattleBtn')?.addEventListener('click', async () => {
    const btn = document.getElementById('startBattleBtn');
    btn.textContent = '⏳ Se încarcă bătălia...';
    btn.disabled    = true;
    document.getElementById('lessonContent').style.display = 'none';

    battleManager = new BattleManager({
      subject:    currentSubject,
      level:      activeLevelNode,
      onDialogue: (text) => typewriterEffect(document.getElementById('dialogueText'), text, 25),
      onUpdateHP: ({ enemyHP, enemyMax, playerHP }) => {
        const ePct = Math.round((enemyHP / enemyMax) * 100);
        const pPct = Math.round((playerHP / 100)    * 100);
        document.getElementById('enemyHpFill').style.width  = Math.max(0, ePct) + '%';
        document.getElementById('playerHpFill').style.width = Math.max(0, pPct) + '%';
        document.getElementById('enemyHpText').textContent  = `${enemyHP}/${enemyMax}`;
        document.getElementById('playerHpText').textContent = `${playerHP}/100`;
      },
      onVictory: () => finishLevel(true),
      onDefeat:  () => finishLevel(false),
    });

    try {
      await battleManager.loadQuestions();
      btn.style.display = 'none';
      showNextQuestion();
    } catch {
      showToast('❌ Lupta nu a putut fi pregătită! Verifică cheia ta Gemini!');
      btn.textContent = '⚔️ Începe Bătălia!';
      btn.disabled    = false;
    }
  });
}

function showNextQuestion() {
  if (!battleManager) return;
  const q = battleManager.currentQuestion();
  if (!q) { battleManager.resolveOutcome(); return; }

  document.getElementById('questionArea').style.display = '';
  document.getElementById('questionText').textContent   = q.question;

  const grid = document.getElementById('answersGrid');
  grid.innerHTML = '';
  q.answers.forEach((ans, idx) => {
    const btn       = document.createElement('button');
    btn.className   = 'answer-btn';
    btn.textContent = ans;
    btn.addEventListener('click', () => handleAnswer(idx, btn));
    grid.appendChild(btn);
  });

  typewriterEffect(
      document.getElementById('dialogueText'),
      `Întrebarea ${battleManager.currentQ + 1} din ${battleManager.questions.length}: Înfruntă această provocare! ⚔️`,
      20
  );
}

async function handleAnswer(idx, clickedBtn) {
  if (!battleManager) return;
  document.querySelectorAll('.answer-btn').forEach(b => b.disabled = true);

  const result = battleManager.answerQuestion(idx);
  if (!result) return;

  const allBtns = document.querySelectorAll('.answer-btn');
  allBtns[result.correct]?.classList.add('correct');
  if (!result.isCorrect) clickedBtn.classList.add('wrong');

  setTimeout(() => {
    if (result.explanation) {
      typewriterEffect(document.getElementById('dialogueText'), '💡 ' + result.explanation, 20);
    }
  }, 600);

  if (result.isCorrect) {
    shakeElement(document.getElementById('enemySprite'));
  } else {
    shakeElement(document.getElementById('playerNameBattle').parentElement);
  }

  await wait(2000);

  if (!battleManager.hasMoreQuestions() || result.gameOver) {
    if (result.won || (!battleManager.hasMoreQuestions() && battleManager.enemyHP < battleManager.playerHP)) {
      await finishLevel(true);
    } else if (battleManager.playerHP <= 0) {
      await finishLevel(false);
    } else {
      battleManager.resolveOutcome();
    }
  } else {
    showNextQuestion();
  }
}

async function finishLevel(won) {
  resetBattleHP();
  const level = activeLevelNode;
  if (!level || !currentUser) return;

  if (won) {
    const rewards = getReward(level.type);
    await completeLevel(currentUser.uid, currentSubject.key, currentLevelIndex, rewards.xp, rewards.gold);

    userData = await loadUserData(currentUser.uid);
    updateHUD(userData);
    await checkAchievements();
    confettiBurst();

    const rewardHTML = `
      ${rewards.xp   > 0 ? `✨ +${rewards.xp} XP`           : ''}
      ${rewards.gold > 0 ? `&nbsp;&nbsp;💰 +${rewards.gold} Aur` : ''}
    `;

    showVictory(
        level.type === 'boss' ? '🐉 Boss Învins!' : '⚔️ Victorie!',
        randomDialogue('victory'),
        rewardHTML
    );

    document.getElementById('victoryOkBtn')?.addEventListener('click', () => {
      hideVictory();
      resetBattleHP();
      if (currentSubject) openLevelMap(currentSubject);
    }, { once: true });

  } else {
    showDefeat(randomDialogue('defeat'));
  }
}

async function checkAchievements() {
  if (!userData || !currentUser) return;
  const uid = currentUser.uid;
  const a   = userData.achievements || [];

  if (userData.lessonsCompleted >= 1 && !a.includes('first_lesson')) {
    await grantAchievement(uid, 'first_lesson');
    showToast('🏆 Realizare: Primii Pași!');
  }
  if (userData.battlesWon >= 1 && !a.includes('first_win')) {
    await grantAchievement(uid, 'first_win');
    showToast('🏆 Realizare: Născut pentru Bătălii!');
  }
  if (activeLevelNode?.type === 'boss' && !a.includes('first_boss')) {
    await grantAchievement(uid, 'first_boss');
    showToast('🏆 Realizare: Ucigaș de Dragoni!');
  }
  if (userData.level >= 10 && !a.includes('level10')) {
    await grantAchievement(uid, 'level10');
    showToast('🏆 Realizare: Cărturar!');
  }
  if (userData.gold >= 100 && !a.includes('gold100')) {
    await grantAchievement(uid, 'gold100');
    showToast('🏆 Realizare: Lăbuță Bogată!');
  }
  if (currentSubject) {
    const prog  = userData.realmProgress?.[currentSubject.key] || {};
    const done  = (prog.completedLevels || []).length;
    if (done >= currentSubject.levels.length && !a.includes('realm_done')) {
      await grantAchievement(uid, 'realm_done');
      showToast('🏆 Realizare: Stăpânul Tărâmului!');
    }
  }
  const allDone = SUBJECTS.every(s => {
    const p = userData.realmProgress?.[s.key] || {};
    return (p.completedLevels || []).length >= s.levels.length;
  });
  if (allDone && !a.includes('all_realms')) {
    await grantAchievement(uid, 'all_realms');
    showToast('🏆 Realizare: Marele Maestru!');
  }
}

// ══ ACCOUNT PAGE ══════════════════════════════
function renderAccountPage() {
  if (!userData) return;

  // Header
  document.getElementById('accAvatar').textContent = '🐱';
  document.getElementById('accName').textContent   = userData.displayName || 'Erou';
  document.getElementById('accClass').textContent  = getHeroClass(userData.level || 1);
  document.getElementById('accBadge').textContent  = getHeroBadge(userData.level || 1);

  // Stats
  document.getElementById('accLevel').textContent   = userData.level            || 1;
  document.getElementById('accXP').textContent      = userData.xp               || 0;
  document.getElementById('accGold').textContent    = userData.gold             || 0;
  document.getElementById('accBattles').textContent = userData.battlesWon       || 0;
  document.getElementById('accLessons').textContent = userData.lessonsCompleted || 0;
  document.getElementById('accStreak').textContent  = userData.streak           || 0;

  // Realm progress
  const progEl = document.getElementById('realmProgress');
  if (progEl) {
    progEl.innerHTML = '';
    SUBJECTS.forEach(subject => {
      const prog = userData.realmProgress?.[subject.key] || {};
      const done = (prog.completedLevels || []).length;
      const pct  = Math.round((done / subject.levels.length) * 100);
      progEl.innerHTML += `
        <div class="realm-progress-row">
          <div class="realm-progress-name">${subject.icon} ${subject.name}</div>
          <div class="realm-p-bar">
            <div class="realm-p-fill" style="width:${pct}%"></div>
          </div>
          <div class="realm-p-pct">${pct}%</div>
        </div>`;
    });
  }

  // Achievements
  const achGrid = document.getElementById('achievementsGrid');
  if (achGrid) {
    achGrid.innerHTML = '';
    ACHIEVEMENTS.forEach(ach => {
      const earned = (userData.achievements || []).includes(ach.id);
      achGrid.innerHTML += `
        <div class="achievement-card ${earned ? 'earned' : ''}">
          <div class="achievement-icon">${earned ? ach.icon : '🔒'}</div>
          <div class="achievement-name">${ach.name}</div>
          ${earned ? `<div class="achievement-desc">${ach.desc}</div>` : ''}
        </div>`;
    });
  }

  // Settings — rendered inline below achievements
  renderSettings(userData);
}

// ══ SHOP ══════════════════════════════════════
function renderShop() {
  const grid = document.getElementById('shopGrid');
  if (!grid) return;
  grid.innerHTML = '';

  SHOP_ITEMS.forEach(item => {
    const owned  = (userData?.inventory || []).includes(item.id);
    const canBuy = (userData?.gold || 0) >= item.price;
    grid.innerHTML += `
      <div class="shop-item">
        <div class="shop-item-icon">${item.icon}</div>
        <div class="shop-item-name">${item.name}</div>
        <div class="shop-item-desc">${item.desc}</div>
        <div class="shop-item-price">💰 ${item.price} Aur</div>
        <button class="buy-btn" data-id="${item.id}" ${!canBuy || owned ? 'disabled' : ''}>
          ${owned ? '✅ Deja Cumpărat' : canBuy ? '💰 Cumpără' : '❌ Aur Insuficient'}
        </button>
      </div>`;
  });
}

function bindShopButtons() {
  document.getElementById('shopGrid')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('.buy-btn');
    if (!btn || btn.disabled) return;
    const itemId = btn.dataset.id;
    const item   = SHOP_ITEMS.find(i => i.id === itemId);
    if (!item || !currentUser) return;

    const success = await buyItem(currentUser.uid, item, userData?.gold || 0);
    if (success) {
      userData = await loadUserData(currentUser.uid);
      updateHUD(userData);
      renderShop();
      showToast(`🛒 Cumpărat ${item.name}!`);
    } else {
      showToast('❌ Aur insuficient!');
    }
  });
}

// ══ OVERLAYS ══════════════════════════════════
function bindOverlayButtons() {
  document.getElementById('defeatRetryBtn')?.addEventListener('click', () => {
    hideDefeat();
    if (activeLevelNode && currentSubject) openBattle(currentSubject, activeLevelNode, currentLevelIndex);
  });

  document.getElementById('defeatRetreatBtn')?.addEventListener('click', () => {
    hideDefeat();
    resetBattleHP();
    if (currentSubject) openLevelMap(currentSubject);
  });
}

// ── Utilities ─────────────────────────────────
function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

function resetBattleHP() {
  document.getElementById('enemyHpFill').style.width  = '100%';
  document.getElementById('playerHpFill').style.width = '100%';
  document.getElementById('enemyHpText').textContent  = '100/100';
  document.getElementById('playerHpText').textContent = '100/100';
}