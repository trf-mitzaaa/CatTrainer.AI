// js/ui.js

// ── Toast notifications ───────────────────────
export function showToast(msg, duration = 3000) {
  const el = document.getElementById('toast');
  if (!el) return;
  // Clear any running timer first
  clearTimeout(el._timer);
  // Reset class so animation re-triggers even if already showing
  el.classList.remove('show');
  el.textContent = msg;
  // Force reflow so the removal registers before re-adding
  void el.offsetHeight;
  el.classList.add('show');
  el._timer = setTimeout(() => el.classList.remove('show'), duration);
}

// ── Show / hide page ──────────────────────────
export function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => {
    p.style.display = p.id === pageId ? '' : 'none';
    p.classList.toggle('active', p.id === pageId);
  });
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.page && pageId.startsWith(btn.dataset.page));
  });
}

// ── Show / hide screen ────────────────────────
export function showScreen(screenId) {
  ['authScreen', 'appScreen'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.style.display = id === screenId ? '' : 'none';
    el.classList.toggle('active', id === screenId);
  });
}

// ── Update HUD bar ────────────────────────────
export function updateHUD(userData) {
  if (!userData) return;

  const level    = userData.level || 1;
  const xp       = userData.xp   || 0;
  const xpNeeded = Math.floor(100 * Math.pow(1.25, level - 1));
  const xpPercent = Math.min((xp / xpNeeded) * 100, 100);

  setText('hudName',    userData.displayName || 'Erou');
  setText('hudLevel',   level);
  setText('hudGold',    userData.gold || 0);
  setText('hudXP',      xp);
  setText('xpVal',      xp);
  setText('xpNeedVal',  xpNeeded);
  setWidth('xpFill',    xpPercent);
}

// ── Helpers ───────────────────────────────────
function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function setWidth(id, pct) {
  const el = document.getElementById(id);
  if (el) el.style.width = Math.min(100, Math.max(0, pct)) + '%';
}

// ── Spawn background paw prints ──────────────
export function spawnPawPrints() {
  const container = document.getElementById('pawBg');
  if (!container) return;
  const paws = ['🐾', '🐾', '🐈', '✨', '🌟'];
  for (let i = 0; i < 18; i++) {
    const el       = document.createElement('span');
    el.className   = 'paw-print';
    el.textContent = paws[Math.floor(Math.random() * paws.length)];
    el.style.left  = Math.random() * 100 + 'vw';
    el.style.top   = Math.random() * 100 + 'vh';
    el.style.fontSize          = (Math.random() * 30 + 20) + 'px';
    el.style.animationDuration = (Math.random() * 15 + 12) + 's';
    el.style.animationDelay    = (Math.random() * 10) + 's';
    container.appendChild(el);
  }
}

// ── Spawn magic particles ─────────────────────
export function spawnParticles() {
  const container = document.getElementById('particles');
  if (!container) return;
  for (let i = 0; i < 25; i++) {
    const el       = document.createElement('span');
    el.className   = 'particle';
    el.style.left  = Math.random() * 100 + 'vw';
    el.style.top   = (50 + Math.random() * 50) + 'vh';
    el.style.animationDuration = (Math.random() * 6 + 4) + 's';
    el.style.animationDelay    = (Math.random() * 8) + 's';
    el.style.width  = (Math.random() * 4 + 2) + 'px';
    el.style.height = el.style.width;
    const hue = [60, 280, 0][Math.floor(Math.random() * 3)];
    el.style.background = `hsl(${hue}, 70%, 65%)`;
    container.appendChild(el);
  }
}

// ── Dialogue typewriter effect ────────────────
export function typewriterEffect(el, text, speed = 30) {
  if (!el) return;
  el.textContent = '';
  let i = 0;
  const timer = setInterval(() => {
    el.textContent += text[i];
    i++;
    if (i >= text.length) clearInterval(timer);
  }, speed);
}

// ── Battle HP update ──────────────────────────
export function updateBattleHP(enemyPct, playerPct) {
  const ef = document.getElementById('enemyHpFill');
  const pf = document.getElementById('playerHpFill');
  if (ef) ef.style.width = Math.max(0, enemyPct) + '%';
  if (pf) pf.style.width = Math.max(0, playerPct) + '%';
}

// ── Shake animation helper ────────────────────
export function shakeElement(el) {
  if (!el) return;
  el.style.animation = 'none';
  void el.offsetHeight; // reflow
  el.style.animation = 'enemyShake 0.5s ease';
}

// ── Victory overlay ───────────────────────────
export function showVictory(title, msg, rewards) {
  setText('victoryTitle', title);
  const msgEl = document.getElementById('victoryMsg');
  if (msgEl) msgEl.textContent = msg;
  const rewardEl = document.getElementById('rewardBox');
  if (rewardEl) rewardEl.innerHTML = rewards;
  const el = document.getElementById('victoryOverlay');
  if (el) el.style.display = 'flex';
}

export function hideVictory() {
  const el = document.getElementById('victoryOverlay');
  if (el) el.style.display = 'none';
}

// ── Defeat overlay ────────────────────────────
export function showDefeat(msg) {
  const msgEl = document.getElementById('defeatMsg');
  if (msgEl) msgEl.textContent = msg;
  const el = document.getElementById('defeatOverlay');
  if (el) el.style.display = 'flex';
}

export function hideDefeat() {
  const el = document.getElementById('defeatOverlay');
  if (el) el.style.display = 'none';
}

// ── Confetti burst ────────────────────────────
export function confettiBurst() {
  const colors = ['#F0C040', '#C0392B', '#7B2D8B', '#F5E6C8', '#4CAF50'];
  for (let i = 0; i < 40; i++) {
    const el            = document.createElement('div');
    el.style.position   = 'fixed';
    el.style.left       = (Math.random() * 100) + 'vw';
    el.style.top        = '-10px';
    el.style.width      = (Math.random() * 10 + 5) + 'px';
    el.style.height     = (Math.random() * 10 + 5) + 'px';
    el.style.background = colors[Math.floor(Math.random() * colors.length)];
    el.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
    el.style.zIndex     = '9998';
    el.style.pointerEvents = 'none';
    el.style.animation  = `confetti ${Math.random() * 2 + 1.5}s ease-out ${Math.random() * 0.5}s forwards`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3500);
  }
}