// js/settings.js
import { auth } from './firebase-config.js';
import {
    updatePassword,
    deleteUser,
    sendEmailVerification,
    reauthenticateWithCredential,
    EmailAuthProvider,
    GoogleAuthProvider,
    reauthenticateWithPopup
} from "https://www.gstatic.com/firebasejs/10.7.0/firebase-auth.js";
import { doc, deleteDoc, updateDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-firestore.js";
import { db } from './firebase-config.js';
import { showToast } from './ui.js';

// ── Check if user signed in with email/password ──
function isEmailUser() {
    const user = auth.currentUser;
    if (!user) return false;
    return user.providerData.some(p => p.providerId === 'password');
}

function isGoogleUser() {
    const user = auth.currentUser;
    if (!user) return false;
    return user.providerData.some(p => p.providerId === 'google.com');
}

// ── Re-authenticate before sensitive actions ──
async function reauthenticate(currentPassword) {
    const user = auth.currentUser;
    if (!user) throw new Error('Nu ești autentificat.');

    if (isEmailUser()) {
        const credential = EmailAuthProvider.credential(user.email, currentPassword);
        await reauthenticateWithCredential(user, credential);
    } else if (isGoogleUser()) {
        const provider = new GoogleAuthProvider();
        await reauthenticateWithPopup(user, provider);
    }
}

// ── Render settings tab content ──────────────
export function renderSettings(userData) {
    const container = document.getElementById('settingsContent');
    if (!container) return;

    const user = auth.currentUser;
    if (!user) return;

    const emailVerified = user.emailVerified;
    const showPasswordSection = isEmailUser();

    container.innerHTML = `
    <!-- Email Verification -->
    <div class="settings-section">
      <div class="settings-section-title">📧 Verificare E-Mail</div>
      ${emailVerified
        ? `<div class="settings-verified-badge">✅ E-Mail verificat${userData?.emailVerifiedBonus ? '' : ' — bonus acordat!'}</div>`
        : `<div class="settings-unverified">
             <p class="settings-hint">Verifică-ți adresa de e-mail pentru a primi <strong>50 💰 aur bonus</strong>!</p>
             <button class="settings-btn settings-btn--gold" id="sendVerifyBtn">
               📧 Trimite e-mail de verificare
             </button>
           </div>`
    }
    </div>

    ${showPasswordSection ? `
    <!-- Change Password -->
    <div class="settings-section">
      <div class="settings-section-title">🔑 Schimbă Parola</div>
      <input type="password" id="currentPasswordInput" class="rpg-input" placeholder="Parola actuală" />
      <input type="password" id="newPasswordInput"     class="rpg-input" placeholder="Parola nouă (min. 6 caractere)" />
      <input type="password" id="confirmPasswordInput" class="rpg-input" placeholder="Confirmă parola nouă" />
      <button class="settings-btn settings-btn--purple" id="changePasswordBtn">
        🔑 Actualizează Parola
      </button>
    </div>
    ` : `
    <div class="settings-section">
      <div class="settings-section-title">🔑 Parolă</div>
      <p class="settings-hint">Contul tău este conectat prin Google. Parola se gestionează din contul Google.</p>
    </div>
    `}

    <!-- Reset Progress -->
    <div class="settings-section settings-section--danger">
      <div class="settings-section-title">🔄 Resetează Progresul</div>
      <p class="settings-hint">Șterge tot progresul tău din joc (XP, aur, nivele completate). Contul rămâne activ.</p>
      <button class="settings-btn settings-btn--warning" id="resetProgressBtn">
        🔄 Resetează Progresul
      </button>
    </div>

    <!-- Delete Account -->
    <div class="settings-section settings-section--danger">
      <div class="settings-section-title">💀 Șterge Contul</div>
      <p class="settings-hint">Această acțiune este permanentă și nu poate fi anulată. Toate datele tale vor fi șterse.</p>
      <button class="settings-btn settings-btn--red" id="deleteAccountBtn">
        💀 Șterge Contul Permanent
      </button>
    </div>
  `;

    // Bind all buttons after rendering
    bindSettingsButtons(userData);
}

// ── Bind settings button events ───────────────
function bindSettingsButtons(userData) {
    // Send verification email
    document.getElementById('sendVerifyBtn')?.addEventListener('click', async () => {
        const btn = document.getElementById('sendVerifyBtn');
        btn.disabled = true;
        btn.textContent = '⏳ Se trimite...';
        try {
            await sendEmailVerification(auth.currentUser);
            showToast('📧 E-mail de verificare trimis! Verifică căsuța ta.');
            btn.textContent = '✅ E-mail trimis!';
        } catch (err) {
            showToast('❌ ' + friendlySettingsError(err.code));
            btn.disabled = false;
            btn.textContent = '📧 Trimite e-mail de verificare';
        }
    });

    // Change password
    document.getElementById('changePasswordBtn')?.addEventListener('click', async () => {
        const current = document.getElementById('currentPasswordInput')?.value;
        const newPwd  = document.getElementById('newPasswordInput')?.value;
        const confirm = document.getElementById('confirmPasswordInput')?.value;

        if (!current || !newPwd || !confirm) {
            return showToast('❌ Completează toate câmpurile!');
        }
        if (newPwd.length < 6) {
            return showToast('❌ Parola nouă trebuie să aibă minim 6 caractere!');
        }
        if (newPwd !== confirm) {
            return showToast('❌ Parolele noi nu coincid!');
        }

        const btn = document.getElementById('changePasswordBtn');
        btn.disabled = true;
        btn.textContent = '⏳ Se actualizează...';

        try {
            await reauthenticate(current);
            await updatePassword(auth.currentUser, newPwd);
            showToast('✅ Parola a fost actualizată cu succes!');
            document.getElementById('currentPasswordInput').value = '';
            document.getElementById('newPasswordInput').value = '';
            document.getElementById('confirmPasswordInput').value = '';
        } catch (err) {
            showToast('❌ ' + friendlySettingsError(err.code));
        } finally {
            btn.disabled = false;
            btn.textContent = '🔑 Actualizează Parola';
        }
    });

    // Reset progress — show confirm modal
    document.getElementById('resetProgressBtn')?.addEventListener('click', () => {
        showConfirmModal({
            icon: '🔄',
            title: 'Resetează Progresul?',
            message: 'Vei pierde tot XP-ul, aurul și nivelele completate. Contul tău rămâne activ. Ești sigur?',
            confirmText: '🔄 Da, resetează',
            confirmClass: 'settings-btn--warning',
            onConfirm: async () => {
                await doResetProgress();
            }
        });
    });

    // Delete account — show confirm modal
    document.getElementById('deleteAccountBtn')?.addEventListener('click', () => {
        showConfirmModal({
            icon: '💀',
            title: 'Șterge Contul?',
            message: 'Această acțiune este PERMANENTĂ. Toate datele tale vor fi șterse și nu pot fi recuperate.',
            confirmText: '💀 Da, șterge tot',
            confirmClass: 'settings-btn--red',
            onConfirm: async () => {
                await doDeleteAccount();
            }
        });
    });
}

// ── Reset Progress ────────────────────────────
async function doResetProgress() {
    const user = auth.currentUser;
    if (!user) return;

    try {
        const ref = doc(db, 'users', user.uid);
        await updateDoc(ref, {
            xp:               0,
            gold:             0,
            level:            1,
            battlesWon:       0,
            lessonsCompleted: 0,
            streak:           0,
            realmProgress:    {},
            achievements:     [],
            inventory:        [],
            lastActivity:     serverTimestamp()
        });
        showToast('🔄 Progresul a fost resetat. Aventura reîncepe!');
        // Reload user data in parent
        window.dispatchEvent(new CustomEvent('userDataReset'));
    } catch (err) {
        showToast('❌ Eroare la resetare. Încearcă din nou.');
        console.error(err);
    }
}

// ── Delete Account ────────────────────────────
async function doDeleteAccount() {
    const user = auth.currentUser;
    if (!user) return;

    // Google users re-auth via popup, email users need password
    if (isEmailUser()) {
        showPasswordConfirmModal(async (password) => {
            try {
                await reauthenticate(password);
                await deleteDoc(doc(db, 'users', user.uid));
                await deleteUser(user);
                showToast('👋 Contul tău a fost șters. La revedere, eroule!');
            } catch (err) {
                showToast('❌ ' + friendlySettingsError(err.code));
            }
        });
    } else {
        try {
            await reauthenticate();
            await deleteDoc(doc(db, 'users', user.uid));
            await deleteUser(user);
            showToast('👋 Contul tău a fost șters. La revedere, eroule!');
        } catch (err) {
            showToast('❌ ' + friendlySettingsError(err.code));
        }
    }
}

// ── Grant email verified bonus ────────────────
export async function checkAndGrantVerifiedBonus(uid, userData) {
    const user = auth.currentUser;
    if (!user) return false;

    // Reload user to get fresh emailVerified status
    await user.reload();

    if (user.emailVerified && !userData?.emailVerifiedBonus) {
        const ref = doc(db, 'users', uid);
        await updateDoc(ref, {
            gold: (userData?.gold || 0) + 50,
            emailVerifiedBonus: true,
            lastActivity: serverTimestamp()
        });
        showToast('✨ E-mail verificat! +50 💰 Aur bonus acordat!');
        return true;
    }
    return false;
}

// ── Confirm Modal ─────────────────────────────
function showConfirmModal({ icon, title, message, confirmText, confirmClass, onConfirm }) {
    // Remove existing modal if any
    document.getElementById('settingsConfirmModal')?.remove();

    const modal = document.createElement('div');
    modal.id = 'settingsConfirmModal';
    modal.className = 'settings-modal-overlay';
    modal.innerHTML = `
    <div class="settings-modal">
      <div class="settings-modal-icon">${icon}</div>
      <h3 class="settings-modal-title">${title}</h3>
      <p class="settings-modal-msg">${message}</p>
      <div class="settings-modal-actions">
        <button class="settings-btn settings-btn--ghost" id="modalCancelBtn">✖ Anulează</button>
        <button class="settings-btn ${confirmClass}" id="modalConfirmBtn">${confirmText}</button>
      </div>
    </div>
  `;

    document.body.appendChild(modal);
    requestAnimationFrame(() => modal.classList.add('visible'));

    document.getElementById('modalCancelBtn').addEventListener('click', () => {
        modal.classList.remove('visible');
        setTimeout(() => modal.remove(), 300);
    });

    document.getElementById('modalConfirmBtn').addEventListener('click', async () => {
        document.getElementById('modalConfirmBtn').disabled = true;
        document.getElementById('modalConfirmBtn').textContent = '⏳ Se procesează...';
        await onConfirm();
        modal.classList.remove('visible');
        setTimeout(() => modal.remove(), 300);
    });

    // Close on backdrop click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('visible');
            setTimeout(() => modal.remove(), 300);
        }
    });
}

// ── Password re-auth modal (for delete, email users) ──
function showPasswordConfirmModal(onConfirm) {
    document.getElementById('settingsConfirmModal')?.remove();

    const modal = document.createElement('div');
    modal.id = 'settingsConfirmModal';
    modal.className = 'settings-modal-overlay';
    modal.innerHTML = `
    <div class="settings-modal">
      <div class="settings-modal-icon">🔐</div>
      <h3 class="settings-modal-title">Confirmă Identitatea</h3>
      <p class="settings-modal-msg">Introdu parola pentru a confirma ștergerea contului.</p>
      <input type="password" id="reAuthPasswordInput" class="rpg-input" placeholder="Parola ta actuală" style="margin: 12px 0;" />
      <div class="settings-modal-actions">
        <button class="settings-btn settings-btn--ghost" id="modalCancelBtn">✖ Anulează</button>
        <button class="settings-btn settings-btn--red" id="modalConfirmBtn">💀 Șterge Contul</button>
      </div>
    </div>
  `;

    document.body.appendChild(modal);
    requestAnimationFrame(() => modal.classList.add('visible'));

    document.getElementById('modalCancelBtn').addEventListener('click', () => {
        modal.classList.remove('visible');
        setTimeout(() => modal.remove(), 300);
    });

    document.getElementById('modalConfirmBtn').addEventListener('click', async () => {
        const pwd = document.getElementById('reAuthPasswordInput').value;
        if (!pwd) return showToast('❌ Introdu parola!');
        document.getElementById('modalConfirmBtn').disabled = true;
        document.getElementById('modalConfirmBtn').textContent = '⏳ Se verifică...';
        await onConfirm(pwd);
        modal.classList.remove('visible');
        setTimeout(() => modal.remove(), 300);
    });

    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('visible');
            setTimeout(() => modal.remove(), 300);
        }
    });
}

// ── Friendly error messages ───────────────────
function friendlySettingsError(code) {
    const map = {
        'auth/wrong-password':        'Parola actuală este greșită.',
        'auth/weak-password':         'Parola nouă trebuie să aibă minim 6 caractere.',
        'auth/requires-recent-login': 'Sesiunea a expirat. Deconectează-te și reconectează-te.',
        'auth/too-many-requests':     'Prea multe încercări. Încearcă mai târziu.',
        'auth/invalid-credential':    'Credențiale invalide. Verifică parola.',
    };
    return map[code] || 'A apărut o eroare. Încearcă din nou.';
}