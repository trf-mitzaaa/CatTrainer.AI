// js/game.js
// ── Subject Realms ─────────────────────────────
export const SUBJECTS = [
  {
    key:   'biology',
    name:  'Biologie',
    icon:  '🧬',
    color: '#27ae60',
    levels: [
      { type: 'lesson', title: 'Bazele Celulei',       icon: '📖', topic: 'biologia celulei, organite, procariote vs eucariote' },
      { type: 'enemy',  title: 'Goblinul Mitozei',    icon: '👺', enemy: '👺 Goblinul Mitozei',    topic: 'diviziunea celulară, fazele mitozei' },
      { type: 'enemy',  title: 'Spectrul ADN',       icon: '👻', enemy: '👻 Spectrul ADN',        topic: 'structura ADN, replicare, împerecherea bazelor' },
      { type: 'enemy',  title: 'Trolul Enzimelor',      icon: '🧟', enemy: '🧟 Trolul Enzimelor',       topic: 'enzime, cataliză, energie de activare' },
      { type: 'boss',   title: 'Dragonul Evoluției',  icon: '🐉', enemy: '🐉 Dragonul Evoluției',   topic: 'selecție naturală, evoluție, genetică' },
    ]
  },
  {
    key:   'math',
    name:  'Matematică',
    icon:  '📐',
    color: '#2980b9',
    levels: [
      { type: 'lesson', title: 'Legendele Algebrei',      icon: '📖', topic: 'algebră de bază, variabile, ecuații, rezolvarea lui x' },
      { type: 'enemy',  title: 'Fantoma Fracțiilor',  icon: '👻', enemy: '👻 Fantoma Fracțiilor',   topic: 'fracții, zecimale, procente, rapoarte' },
      { type: 'enemy',  title: 'Garguiul Geometriei', icon: '🗿', enemy: '🗿 Garguiul Geometriei',  topic: 'geometrie, unghiuri, arie, perimetru, teorema lui Pitagora' },
      { type: 'enemy',  title: 'Năluca Calculului',   icon: '🧛', enemy: '🧛 Năluca Calculului',    topic: 'derivate și integrale de bază, limite' },
      { type: 'boss',   title: 'Titanul Marelui Sigma', icon: '🔱', enemy: '🔱 Titanul Marelui Sigma',  topic: 'matematică avansată: șiruri, serii, statistici, probabilități' },
    ]
  },
  {
    key:   'history',
    name:  'Istorie',
    icon:  '🏛️',
    color: '#8e44ad',
    levels: [
      { type: 'lesson', title: 'Pergamente Antice',   icon: '📖', topic: 'civilizații antice: Egipt, Grecia, Roma' },
      { type: 'enemy',  title: 'Cavalerul Medieval',   icon: '⚔️', enemy: '⚔️ Cavalerul Medieval',    topic: 'evul mediu, feudalism, cruciade, ciuma neagră' },
      { type: 'enemy',  title: 'Spectrul Revoluției',icon: '🔥', enemy: '🔥 Spectrul Revoluției', topic: 'revoluția franceză, revoluția americană, revoluția industrială' },
      { type: 'enemy',  title: 'Colosul Războiului',      icon: '💣', enemy: '💣 Colosul Războiului',        topic: 'Primul și Al Doilea Război Mondial: cauze, evenimente, rezultate' },
      { type: 'boss',   title: 'Chronos, Zeul Timpului', icon: '⏳', enemy: '⏳ Chronos, Zeul Timpului', topic: 'istoria modernă, Războiul Rece, decolonizare, globalizare' },
    ]
  },
  {
    key:   'chemistry',
    name:  'Chimie',
    icon:  '⚗️',
    color: '#e67e22',
    levels: [
      { type: 'lesson', title: 'Introducere în Alchimie',    icon: '📖', topic: 'tabelul periodic, structura atomului, concepte de bază în chimie' },
      { type: 'enemy',  title: 'Slime Acid',        icon: '🟢', enemy: '🟢 Slime Acid',          topic: 'acizi, baze, scala pH, reacții de neutralizare' },
      { type: 'enemy',  title: 'Demonul Reacțiilor',    icon: '😈', enemy: '😈 Demonul Reacțiilor',       topic: 'reacții chimice, echilibrarea ecuațiilor, stoechiometrie' },
      { type: 'enemy',  title: 'Golemul Compușilor',    icon: '🗿', enemy: '🗿 Golemul Compușilor',       topic: 'legături chimice, ionic vs covalent, geometrie moleculară' },
      { type: 'boss',   title: 'Lordul Mendeleev',    icon: '⚗️', enemy: '⚗️ Lordul Mendeleev',      topic: 'chimie avansată: termodinamică, cinetică, echilibru chimic' },
    ]
  },
  {
    key:   'physics',
    name:  'Fizică',
    icon:  '🔭',
    color: '#16a085',
    levels: [
      { type: 'lesson', title: 'Legendele Forțelor',       icon: '📖', topic: 'legile lui Newton, forțe, masă, accelerație' },
      { type: 'enemy',  title: 'Năluca Gravitației',    icon: '🌀', enemy: '🌀 Năluca Gravitației',       topic: 'gravitație, mișcare circulară, mecanică orbitală' },
      { type: 'enemy',  title: 'Banshee-ul Undelor',      icon: '👾', enemy: '👾 Banshee-ul Undelor',         topic: 'unde, sunet, lumină, spectrul electromagnetic' },
      { type: 'enemy',  title: 'Regele Anghilă Electrică', icon: '⚡', enemy: '⚡ Regele Anghilă Electrică',     topic: 'electricitate, circuite, magnetism, legea lui Ohm' },
      { type: 'boss',   title: 'Fantoma lui Einstein', icon: '👁️', enemy: '👁️ Fantoma lui Einstein',    topic: 'relativitate, mecanică cuantică, fizică modernă' },
    ]
  },
  {
    key:   'literature',
    name:  'Literatură',
    icon:  '📚',
    color: '#c0392b',
    levels: [
      { type: 'lesson', title: 'Pergamentele Poveștii',     icon: '📖', topic: 'figuri de stil, structură narativă, genuri literare, punct de vedere' },
      { type: 'enemy',  title: 'Demonul Găurilor de Plot',  icon: '🕳️', enemy: '🕳️ Demonul Găurilor de Plot',    topic: 'structura poveștii, intrigă, conflict, rezoluție' },
      { type: 'enemy',  title: 'Năluca Gramaticii',    icon: '✒️', enemy: '✒️ Năluca Gramaticii',       topic: 'gramatică, sintaxă, tehnici de analiză literară' },
      { type: 'enemy',  title: 'Sfinxul Metaforei',   icon: '🦁', enemy: '🦁 Sfinxul Metaforei',      topic: 'limbaj figurat, simbolism, alegorie, temă' },
      { type: 'boss',   title: 'Dragonul Bardului',   icon: '🎭', enemy: '🎭 Dragonul Bardului',      topic: 'Shakespeare, literatură clasică, poezie, dramaturgie' },
    ]
  }
];

// ── Shop Items ────────────────────────────────
export const SHOP_ITEMS = [
  { id: 'hp_potion',   name: 'Poțiune HP',       icon: '🧪', desc: 'Restaurează 30 HP în luptă',     price: 50,  effect: { hp: 30 } },
  { id: 'xp_boost',   name: 'Pergament XP',        icon: '📜', desc: 'Câștigi 1.5× XP în următoarea bătălie', price: 80,  effect: { xpMult: 1.5 } },
  { id: 'hint_stone', name: 'Piatra Indiciului',        icon: '💎', desc: 'Dezvăluie un răspuns greșit în luptă', price: 60, effect: { hints: 1 } },
  { id: 'cat_charm',  name: 'Amuletă Pisică Norocoasă',   icon: '🐱', desc: 'Șansă ca răspunsurile greșite să devină punctaj parțial', price: 120, effect: { luck: true } },
  { id: 'time_hourglass', name: 'Clepsidra Timpului', icon: '⏳', desc: 'Primești timp extra pentru fiecare întrebare', price: 70,  effect: { extraTime: 15 } },
  { id: 'shield',     name: 'Scut Magic',      icon: '🛡️', desc: 'Blochează penalizarea unui răspuns greșit', price: 100, effect: { shield: 1 } },
];

// ── Achievements ──────────────────────────────
export const ACHIEVEMENTS = [
  { id: 'first_lesson',  name: 'Primii Pași',    icon: '👣', desc: 'Completează prima ta lecție' },
  { id: 'first_win',     name: 'Născut pentru Luptă',    icon: '⚔️', desc: 'Câștigă prima bătălie' },
  { id: 'first_boss',    name: 'Ucigaș de Dragoni',  icon: '🐉', desc: 'Învinge primul boss' },
  { id: 'level10',       name: 'Cărturar',        icon: '🎓', desc: 'Atinge Nivelul 10' },
  { id: 'gold100',       name: 'Lăbuță Bogată',    icon: '💰', desc: 'Strânge 100 de aur' },
  { id: 'streak3',       name: 'În Flăcări!',       icon: '🔥', desc: 'Serie de 3 zile de învățare' },
  { id: 'realm_done',    name: 'Stăpânul Tărâmului',   icon: '👑', desc: 'Completează toate nivelurile unui tărâm' },
  { id: 'all_realms',    name: 'Marele Maestru',   icon: '🌟', desc: 'Completează toate tărâmurile' },
];

// ── Hero class by level ───────────────────────
export function getHeroClass(level) {
  if (level >= 50) return 'Mare Savant Arcane';
  if (level >= 30) return 'Maestru Arcane';
  if (level >= 20) return 'Mag al Cunoașterii';
  if (level >= 10) return 'Învățăcel Avansat';
  if (level >= 5)  return 'Ucenic Cărturar';
  return 'Învățăcel Novice';
}

export function getHeroBadge(level) {
  if (level >= 50) return '👑 Mare Maestru';
  if (level >= 30) return '🌟 Maestru';
  if (level >= 20) return '💎 Expert';
  if (level >= 10) return '🥇 Cărturar';
  if (level >= 5)  return '🥈 Ucenic';
  return '🏅 Începător';
}

// ── XP to next level ──────────────────────────
export function xpForLevel(level) { return level * 100; }

// ── Rewards per level type ────────────────────
export function getReward(levelType) {
  switch (levelType) {
    case 'lesson': return { xp: 20, gold: 0 };
    case 'enemy':  return { xp: 40, gold: 25 };
    case 'boss':   return { xp: 100, gold: 75 };
    default:       return { xp: 20, gold: 0 };
  }
}

// ── Cat Game Master dialogues ─────────────────
export const GM_DIALOGUES = {
  welcome: [
    'Miau! Bine ai venit în tărâmul meu, tânăr învățăcel! 🐱',
    'Purrr... Ești gata să înveți?',
    'Pisica înțeleaptă știe: cunoașterea este cea mai mare comoară! ✨'
  ],

  lesson: [
    'E timpul să studiezi, tinere! Absoarbe aceste rune străvechi... 📜',
    'Chiar și o pisică știe să observe înainte să sară! Citește cu atenție... 👁️',
    'Miau! Această cunoaștere îți va fi de folos în bătălie! 🐾'
  ],

  battle: [
    'Un provocator se apropie! Arată ce știi! ⚔️',
    'Hiss! Dovedește-ți valoarea, învățăcelule! 😼',
    'Luptă cu mintea, nu cu ghearele! 🧠'
  ],

  correct: [
    'Purrfect! Exact corect! 🐱✨',
    'Nyaa~! Răspuns strălucit! 💫',
    'Da! Cunoașterea curge prin tine! ⚡'
  ],

  wrong: [
    'Hiss... Asta a fost greșit, tinere. 😾',
    'Miau... Studiază mai mult! Fiecare greșeală este o lecție. 📚',
    'Nu chiar... Amintește-ți ce spun pergamentele! 🔮'
  ],

  victory: [
    'URLETUL VICTORIEI! Ai învins inamicul! 🎉',
    'Purrr! Știam că poți, învățăcelule! 🌟',
    'Magnific! Tărâmul se înclină în fața înțelepciunii tale! 👑'
  ],

  defeat: [
    'Miau... Ai fost învins. Dar un adevărat învățăcel nu renunță niciodată! 🐾',
    'Chiar și pisicile mai cad uneori. Ridică-te și studiază din nou! 😿',
    'Inamicul a fost puternic, dar cunoașterea crește cu fiecare bătălie! 📖'
  ],

  boss_warn: [
    'AI GRIJĂ! Un boss înfricoșător te așteaptă mai departe! Pregătește-te, tinere! ⚠️',
    '*hiss* Acesta nu este un adversar obișnuit! Studiază bine înainte să-l înfrunți! 🔥',
    'Gardianul final este aproape... Pune-ți la încercare toată cunoașterea! 🐉'
  ],
};

export function randomDialogue(key) {
  const arr = GM_DIALOGUES[key] || GM_DIALOGUES.welcome;
  return arr[Math.floor(Math.random() * arr.length)];
}
