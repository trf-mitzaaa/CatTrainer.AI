import { randomDialogue } from './game.js';

const GEMINI_API_KEY = 'AIzaSyAYJ5lT_PFwr9ypUXV0nCxkroZHELCbwp4'; // ← Replace with your key
const GEMINI_URL     = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=${GEMINI_API_KEY}`;

// ── Call Gemini ───────────────────────────────
async function askGemini(prompt) {
  try {
    const res = await fetch(GEMINI_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature:     0.4,
          maxOutputTokens: 1024,
        }
      })
    });
    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || '';
  } catch (err) {
    console.error('Gemini error:', err);
    throw err;
  }
}

// ── Generate Lesson Content ───────────────────
export async function generateLesson(topic) {
  const prompt = `Ești Magicianul Whiskers, o pisică Game Master înțeleaptă și jucăușă care îi învață pe elevi într-un joc educațional în stil RPG numit CatTrainer.

Generează o lecție distractivă și captivantă despre: ${topic}

Formatează răspunsul astfel:

📜 Titlu: [Titlu atractiv]

[3–4 paragrafe de explicații clare și captivante, scrise într-un ton normal. Aceste lecții sunt pentru elevi de liceu, deci le scrii într-un ton normal. Folosește emoji-uri cu moderație. Include fapte importante, exemple și mnemonici ușor de reținut.]

🐾 Idei cheie:
• [Ideea 1]
• [Ideea 2]
• [Ideea 3]
• [Ideea 4]

Menține lungimea totală între 250–350 de cuvinte. Fă lecția educativă, dar și distractivă!`;

  return await askGemini(prompt);
}

// ── Generate Battle Question ──────────────────
export async function generateQuestion(topic, difficulty = 'medium', previousQuestions = []) {
  const prevList = previousQuestions.length > 0
    ? `Evită aceste subiecte deja folosite: ${previousQuestions.join(', ')}.`
    : '';

  const prompt = `Ești Profesorul Whiskers, un Game Master pisică într-un joc educațional RPG numit CatTrainer.

Generează O singură întrebare cu răspunsuri multiple despre: ${topic}
Dificultate: ${difficulty}
${prevList}

RĂSPUNDE DOAR CU JSON valid, fără markdown și fără text suplimentar:
{
  "question": "Textul întrebării aici?",
  "answers": ["Răspuns corect", "Răspuns greșit 2", "Răspuns greșit 3", "Răspuns greșit 4"] (răspunsurile nu trebuie să fie întotdeauna în aceeași ordine),
  "correct": 0,
  "explanation": "Nu trebuie explicații. Lasă gol aici"
}

Reguli:
- "correct" este indexul 0-3 al răspunsului corect din "answers".
- Amestecă răspunsurile, ca răspunsul corect să nu fie mereu primul.
- Întrebarea trebuie să fie scurtă, clară și potrivită pentru un joc RPG educațional.
- Folosește maximum 18 cuvinte pentru întrebare.
- Testează un singur concept.
- Evită formulările lungi, academice sau de olimpiadă.
- Răspunsurile trebuie să fie scurte, maximum 12 cuvinte fiecare.
- Răspunsurile greșite trebuie să fie plauzibile, dar clar incorecte.
- Nu folosi expresii precum „dincolo de”, „în contextul”, „ce eveniment critic”.
- Scrie ca pentru elevi de liceu, nu ca pentru experți.`;

  const raw = await askGemini(prompt);
  try {
    const clean = raw.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  } catch {
    // Fallback question
    return {
      question: `Care dintre acestea sunt ADEVĂRATE despre ${topic}?`,
      answers: [
        'Urmează principiile științifice predate la clasă',
        'Nu are nicio legătură cu știința consacrată',
        'Contrazice toate cercetările moderne',
        'Nimeni nu a studiat încă acest subiect'
      ],
      correct: 0,
      explanation: 'Primul răspuns reflectă înțelegerea corectă a subiectului.'
    };
  }
}

// ── Generate Batch of Questions (boss battles) ────
export async function generateBattleSet(topic, count = 5) {
  const questions = [];
  const diffs = count <= 3
    ? ['easy', 'medium', 'hard'].slice(0, count)
    : ['easy', 'easy', 'medium', 'medium', 'hard'];

  for (let i = 0; i < count; i++) {
    const q = await generateQuestion(topic, diffs[i] || 'medium', questions.map(q => q.question));
    questions.push(q);
  }
  return questions;
}

// ── Battle State Manager ──────────────────────
export class BattleManager {
  constructor({ subject, level, onDialogue, onUpdateHP, onVictory, onDefeat }) {
    this.subject     = subject;
    this.level       = level;
    this.onDialogue  = onDialogue;
    this.onUpdateHP  = onUpdateHP;
    this.onVictory   = onVictory;
    this.onDefeat    = onDefeat;

    this.questions   = [];
    this.currentQ    = 0;
    this.playerHP    = 100;
    this.enemyHP     = 100;
    this.maxHP       = 100;
    this.correct     = 0;
    this.streak      = 0;

    // boss has more HP
    if (level.type === 'boss') {
      this.enemyHP = 150;
      this.maxHP   = 150;
    }
  }

  async loadQuestions() {
    const count  = this.level.type === 'boss' ? 5 : 3;
    this.questions = await generateBattleSet(this.level.topic, count);
  }

  currentQuestion() {
    return this.questions[this.currentQ] || null;
  }

  answerQuestion(answerIndex) {
    const q = this.currentQuestion();
    if (!q) return null;

    const isCorrect = (answerIndex === q.correct);
    let damage, playerDamage;

    if (isCorrect) {
      this.correct++;
      this.streak++;
      damage      = this.level.type === 'boss' ? 30 : 35;
      playerDamage = 0;
      if (this.streak >= 2) damage += 10; // streak bonus
      this.onDialogue(randomDialogue('correct'));
    } else {
      this.streak  = 0;
      damage       = 0;
      playerDamage = this.level.type === 'boss' ? 30 : 25;
      this.onDialogue(randomDialogue('wrong'));
    }

    this.enemyHP  = Math.max(0, this.enemyHP - damage);
    this.playerHP = Math.max(0, this.playerHP - playerDamage);

    this.onUpdateHP({
      enemyHP:    this.enemyHP,
      enemyMax:   this.maxHP,
      playerHP:   this.playerHP,
      playerMax:  100,
    });

    const result = {
      isCorrect,
      damage,
      playerDamage,
      explanation: q.explanation,
      correct:     q.correct,
      gameOver:    this.enemyHP <= 0 || this.playerHP <= 0,
      won:         this.enemyHP <= 0,
    };

    this.currentQ++;
    return result;
  }

  hasMoreQuestions() {
    return this.currentQ < this.questions.length && this.playerHP > 0 && this.enemyHP > 0;
  }

  getAccuracy() {
    return this.questions.length > 0 ? Math.round((this.correct / this.currentQ) * 100) : 0;
  }

  resolveOutcome() {
    // If all questions done and enemy still standing, compare HP
    if (this.enemyHP > 0 && this.playerHP > 0) {
      if (this.enemyHP < this.playerHP) {
        this.onVictory();
      } else {
        this.onDefeat();
      }
    } else if (this.enemyHP <= 0) {
      this.onVictory();
    } else {
      this.onDefeat();
    }
  }
}
